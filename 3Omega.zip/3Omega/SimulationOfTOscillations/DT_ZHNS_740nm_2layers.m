% Temperature oscilations of ZrHfNiSn (740 nm)
% heater - Au
% layer 1 - Al2O3
% layer 2 - Zr0.5Hf0.5NiSn
% layer 3 - MgO
close all, clear all, clc
%% Plot 1
%Parameters
D1 = 1.54e-5; %cross plane thermal diffusivity
D2 = 1.6e-6;
D3 = 1.34e-5;
d1 = 2.5e-7; %layer thickness
d2 = 7e-7;
d3 = 1e-3;
k1 = 46; %thermal conductivity
k2 = 0.7;
k3 = 42;
b  = 8.9167e-6; %half width of the heater
Pl = 18; %heating power per heater length
dk = 1; %integration step
f  = [100:10:900 1000:100:9e3 1e4:1e3:1e5];
%Calculations
DT = TempOsc3(D1, D2, D3, d1, d2, d3, k1, k2, k3, b, Pl, f, dk);
%% Plot 2
%Parameters for heater (Au)
%dh    = 5e-8; %thickness
%ChRoh = 2.492e6; %heat capacity per unit volume
%Rth   = 1e-9; % thermal boundary resistance
%Calculations
%DTstar = (DT + Rth*Pl/(2*b))./(1 + ChRoh*dh*1i*2*2*pi*f.*(Rth + DT*2*b/Pl));
%% Plots
semilogx(f, real(DT));
%semilogx(f,real(DT),'r',f,real(DTstar),'b');
%legend('DT ZHNS 740 nm', 'DTstar');
grid on;