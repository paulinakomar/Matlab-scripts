close all, clear all,clc
%% Parameters
D1 = 5e-6;
D2 = 1.3377e-5;
d1 = 7e-7;
d2 = 0.5;
k1 = 4.4;
k2 = 42;
b  = 1e-5;
P  = 18;
W  = zeros(1,415);
N = 100;
DT = 0;
s = -1;
%%
tic
p=1;
f = [10:1:90 100:10:900 1000:100:9e3 1e4:1e3:9e4 1e5:1e4:1e6];
k = 1e-30:1:N;
%f =10:100:1e6;

for w = 1:length(f);
    wr=f(w)*2*pi;
    DT = 0;
    B1 = sqrt(k.^2 + (2*wr*1i)/D1);
    B2 = sqrt(k.^2 + (2*wr*1i)/D2);
    A2 = -1./tanh(B2.*d2);
    A1 = (((A2*k2.*B2)./(k1.*B1))-tanh(B1.*d1))./(1-((A2.*k2.*B2.*tanh(B1.*d1))./(k1.*B1)));
    DT = - (P/(pi.*k1))*(((sin(b.*k)).^2)./(A1.*B1.*(b.^2)*(k.^2)));
    W(w) = DT;
    clc 
    (w/415)*100
end
time = toc;

%%
semilogx(f,real(W));
time