close all, clear all, clc
%% Plot 1
%Parameters
D1 = 8.3e-7;
D2 = 8.8e-5;
d1 = 4e-7;
d2 = 6.5e-4;
k1 = 1.1;
k2 = 156;
b  = 5e-6;
Pl = 1;
dk = 1;
f  = [10:1:90 100:10:900 1000:100:9e3 1e4:1e3:9e4 1e5:1e4:1e6];
%Calculations
DT = TempOsc(D1, D2, d1, d2, k1, k2, b, Pl, f, dk);
%% Plot 2
%Parameters
dh    = 1.75e-7;
ChRoh = 2.85e6;
Rth   = 2e-8;
%Calculations
DTstar = (DT + Rth*Pl/(2*b))./(1 + ChRoh*dh*1i*2*2*pi*f.*(Rth + DT*2*b/Pl));
%% Plots
semilogx(f,real(DT),'r',f,real(DTstar),'b');
legend('DT', 'DTstar');
grid on;