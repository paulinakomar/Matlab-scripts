% Temperature oscilations of ZrHfNiSn (740 nm)
% heater - Au
% layer 1 - Al2O3 (amorphous)
% layer 2 - Zr0.5Hf0.5NiSn
% layer 3 - V
% layer 4 - MgO

% k4 var
close all, clear all, clc
%% Plot 1
%Parameters
D1 = 9.5e-7; %cross plane thermal diffusivity
D2 = 1.6e-6;
D3 = 1.044e-5;
D4 = 1.37e-5;
d1 = 2.5e-7; %layer thickness
d2 = 7e-7;
d3 = 1e-8;
d4 = 5e-4;
k1 = 1.8; %thermal conductivity
k2 = 0.9;
k3 = 2;
k4 = 44;
b  = 8.9167e-6; %half width of the heater
Pl = 18; %heating power per heater length
dk = 1; %integration step
f  = [50:10:900 1000:100:9e3 1e4:1e3:1e5];
%Calculations
for k4=1:15
    %DT(k1,:) = TempOsc3(D1, D2, D3, d1, d2, d3, k1+39, k2, k3, b, Pl, f, dk);
    DT(k4,:) = TempOsc4(D1, D2, D3, D4, d1, d2, d3, d4, k1, k2, k3, k4+39, b, Pl, f, dk);
    str = sprintf('Gotowe %d%% \n', round((k4*100)/15));
    clc
    disp(str);
end
%DT = TempOsc4(D1, D2, D3, D4, d1, d2, d3, d4, k1, k2, k3, k4, b, Pl, f, dk);

%% Plot 2
%Parameters for heater (Au)
dh    = 5e-8; %thickness
ChRoh = 2.492e6; %heat capacity per unit volume
Rth   = 1e-9; % thermal boundary resistance
%Calculations
% DTstar = (DT + Rth*Pl/(2*b))./(1 + ChRoh*dh*1i*2*2*pi*f.*(Rth + DT*2*b/Pl));
%% Plots
Data=load('ZHNS2.dat');
semilogx(f, real(DT));
hold on;

figure(1)
for i=1:15
    semilogx(f, real(DT(i,:)));
    hold on
end

semilogx(Data(:,1), Data(:,2),'or');
semilogx(Data(:,1), Data(:,3),'ok');
%semilogx(f,real(DTstar),'g');
%legend('DT ZHNS 700 nm', 'ZH 25', 'ZH 26', 'DTstar');
grid on;