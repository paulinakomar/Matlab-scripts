close all, clear all,clc
%% Parameters
D1 = 8.3e-7;
D2 = 8.8e-5;
d1 = 1e-6;
d2 = 6.5e-4;
k1 = 1.1;
k2 = 156;
b  = 5e-6;
P  = 1;
W  = zeros(1,415);
N = 630000;
DT = zeros(1,N);
s = -1;
dk = 1;
%%
tic
%p=1;
f = [10:1:90 100:10:900 1000:100:9e3 1e4:1e3:9e4 1e5:1e4:1e6];
%f =10:100:1e6;
%f = 1000000;

for w = 1:length(f);
    z=1;
    wr=f(w)*2*pi;
    for k = 1e-30:dk:N
        B1 = sqrt(k^2 + (2*wr*1i)/D1);
        B2 = sqrt(k^2 + (2*wr*1i)/D2);
        A2 = -1/tanh(B2*d2);
        A1 = (((A2*k2*B2)/(k1*B1))-tanh(B1*d1))/(1-((A2*k2*B2*tanh(B1*d1))/(k1*B1)));
        DT(z) = -P*(((sin(b*k))^2)/(A1*B1*(b^2)*(k^2)))*dk;
        z=z+1;
    end
    W(w) = sum(DT);
    DT = zeros(1,N);
    %p = p + 1;
    clc 
    (w/415)*100
end
time = toc;

%%
semilogx(f,real(W));
%semilogx(real(DT));
grid on;
time