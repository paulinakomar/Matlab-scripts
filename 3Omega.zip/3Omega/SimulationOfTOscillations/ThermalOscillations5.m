close all, clear all,clc
%% Parameters
D1 = 1.2e-5;
D2 = 1.6e-6;
D3 = 1.59e-5;
d1 = 2.5e-7;
d2 = 7.4e-7;
d3 = 5e-4;
k1 = 30;
k2 = 3;
k3 = 50;
b  = 1e-5;
P  = 0.018;
l = 1e-3;
W  = zeros(1,253);
N = 300000;
DT = zeros(1,N);
s = -1;
%%
tic
p=1;
%f = [100:10:900 1000:100:9e3 1e4:1e3:1e5];
%f =10:100:1e6;
f = 10000;
for w = 1:length(f);
    z=1;
    wr=f(w)*2*pi;
    for k = 1e-30:1:N
        Pl = P/l;
        B1 = sqrt(k^2 + (2*wr*1i)/D1);
        B2 = sqrt(k^2 + (2*wr*1i)/D2);
        B3 = sqrt(k^2 + (2*wr*1i)/D3);
        %A3 = -tanh((B3*d3)^s);
        A3 = -1/tanh(B3*d3);
        A2 = (((A3*k3*B3)/(k2*B2))-tanh(B2*d2))/(1-((A3*k3*B3*tanh(B2*d2))/(k2*B2)));
        A1 = (((A2*k2*B2)/(k1*B1))-tanh(B1*d1))/(1-((A2*k2*B2*tanh(B1*d1))/(k1*B1)));
        DT(z) = (-Pl/(pi*k1))*(((sin(b*k))^2)/(A1*B1*(b*k)^2));
        z=z+1;
    end
    %W(p) = sum(DT);
    %DT = zeros(1,N);
    %p = p + 1;
    clc 
    (w/253)*100
end
time = toc;

%%

semilogx(real(DT));
grid on
time