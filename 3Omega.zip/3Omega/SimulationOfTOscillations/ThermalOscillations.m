close all, clear all,clc
%% Parameters
D1 = 8.3e-7;
D2 = 8.8e-5;
d1 = 4e-7;
d2 = 6.5e-4;
k1 = 1.1;
k2 = 156;
b  = 5e-6;
one= 1;
P  = 1;
W  = [];
N = 10000;
DT = zeros(1,N);

%%
for w = 10:10:1e6
%w=10;
z=1;
    for k = 1e-10:1:N
        B1 = (k^2 + (2*w*1i)/D1)^0.5;
        B2 = (k^2 + (2*w*1i)/D2)^0.5;
        A1 = -(tanh(one)*k2*B2*tanh(B1*d1)/(k1*B1))/(1 - tanh(one)*k2*tanh(B1*d1)/k1);
        DT(z) = -P*(sin(b*k))^2/(A1*B1*b^2*k^2);
        z=z+1;
    end
    W = [W sum(DT)];
    clc
    (w/1e6)*100
end


%%
x = 10:10:1e6;
semilogx(x,W);