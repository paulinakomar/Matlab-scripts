%Porownanie oscylaci temperaturowych dla dwoch roznych szerokosci grzejnika
%na podstawie artykulu (Raudzis, J.Appl.Phys., vol 93, nr 10, 2003),
%equation 1, figure 2
close all, clear all,clc
%% Plot 1
%Parameters
D1 = 8.3e-7;
D2 = 8.8e-5;
d1 = 1e-6;
d2 = 6.5e-4;
k1 = 1.1;
k2 = 156;
b  = 5e-6;
Pl  = 1;
dk = 1;
f = [10:1:90 100:10:900 1000:100:9e3 1e4:1e3:9e4 1e5:1e4:1e6];
%Calculations
DT1 = TempOsc2(D1, D2, d1, d2, k1, k2, b, Pl, f, dk);
disp('First plot ready');
%% Plot 2
%Parameters
b = 1e-5;
%Calculations
DT2 = TempOsc2(D1, D2, d1, d2, k1, k2, b, Pl, f, dk);
%%
semilogx(f,real(DT1),'r',f,real(DT2),'b');
legend('10 mikro', '20 mikro');
grid on;