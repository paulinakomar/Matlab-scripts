close all, clear all,clc

%% Parameters
Ra = load('Ra.txt');
Rb = load('Rb.txt');
T = load('T.txt');
d = 11e-9;
k = 51;

%% Calculations
[Rs, Rs_real, rho, CtrlSum] = vanDerPauw(k, Ra, Rb, T, d);

%% save data
csvwrite('V35_Rs.dat', Rs_real);

%% Specific resistivity calculated from the measured data and literature value

rho_long = load('SpecRes_LongSide.txt');
rho_short = load('SpecRes_ShortSide.txt');

V_literature = load('V_literature.txt');

%% Plots
figure1 = figure();
axes1 = axes('Parent',figure1,'FontSize',14);
box(axes1,'on');
hold(axes1,'all');
    plot(T, rho, 'r', 'LineWidth', 2);
    plot(T, rho_long, 'b', 'LineWidth', 2);
    plot(T, rho_short, 'k', 'LineWidth', 2);
    plot(V_literature(:,1), V_literature(:,2), 'g', 'LineWidth', 2);
        legend('specific resitivity, Taylor series 51st order', 'along long side', 'along short side', 'literature data',...
               'Location', 'NorthWest');
        xlabel('T (K)','FontSize',14);
        ylabel('specific resistivity (Ohm m)','FontSize',14);
    print(figure1, '-dpng', 'V35_SpecificResistivity', '-r300');
        
figure2 = figure();
axes2 = axes('Parent',figure2,'FontSize',14);
box(axes2,'on');
hold(axes2,'all');
    plot(T, CtrlSum, 'r', 'LineWidth', 2)
        legend('Control sum, Taylor series 51st order');
        xlabel('T (K)','FontSize',14);
        ylabel('van der Pauw','FontSize',14);
        title('exp(-pi*Ra/Rs)+exp(-pi*Rb/Rs)','FontSize',16);
    print(figure2, '-dpng', 'V35_ControlSum', '-r300');