close all, clear all, clc

%% names of the output files
name_old = [5 6 7 8 9 11];
PdfFileName_old = 'OldData_2010';
PngFileName_old = 'OldData_2010';

figure1 = figure('PaperOrientation', 'landscape', 'PaperType', 'A4');
    annotation('textbox', [.41 .9 .5 .1], 'String', 'MgO substrates 2010', 'LineStyle', 'none', 'FontSize', 18);
% text(0.4, 0.5,'tekst', 'FontSize', 18);

for i=1:length(name_old)
    RC_MgO = importdata(sprintf('THZ_%0.f_MgO_rc.txt', name_old(i)));
    
    subplot(2,3,i);
        RC_MgO_plot(RC_MgO);
end

%% save to the file
set(figure1, 'PaperPosition', [-0.5 -0.25 30 20]); 
    saveas(figure1, PdfFileName_old, 'pdf');
    print(figure1, '-dpng', PngFileName_old, '-r500');
    
% ------------------------

%% names of the output files
name_new = {'SL-TH_1'; 'SL-TH_2'; 'SL-TH_3'; 'T6'};
PdfFileName_new = 'NewData_2013';
PngFileName_new = 'NewData_2013';

figure2 = figure('PaperOrientation', 'landscape', 'PaperType', 'A4');
    annotation('textbox', [.41 .9 .5 .1], 'String', 'MgO substrates 2013', 'LineStyle', 'none', 'FontSize', 18);
    
for i=1:length(name_new)
    RC_MgO = importdata(sprintf('%s_MgO_rc.txt', name_new{i}));
    
    subplot(2,2,i);
        RC_MgO_plot(RC_MgO);
end

%% save to the file
set(figure2, 'PaperPosition', [-0.5 -0.25 30 20]); 
    saveas(figure2, PdfFileName_new, 'pdf');
%     print(figure2, '-dpng', PngFileName_new, '-r500');