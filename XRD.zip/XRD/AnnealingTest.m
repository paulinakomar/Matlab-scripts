clear all, close all, clc

folder    = '\\fs01\holuj$\Dokumente\Results\XRD\SL-TH\SL-TH_61-heatingCycles';
names     = {'SL-TH_61_fs_beforeHeating'; 'SL-TH_61_fs_200C'; 'SL-TH_61_fs_300C';...
            'SL-TH_61_fs_400C'; 'SL-TH_61_fs_500C'; 'SL-TH_61_fs_600C';...
            'SL-TH_61_fs_700C'; 'SL-TH_61_fs_800C'; 'SL-TH_61_fs_vf650C';...
            'SL-TH_61_fs_vf720C'; 'SL-TH_61_fs_vf790C'; 'SL-TH_61_fs_vf860C'};
roughness = [4.46, 2.49, 3.74, 3.92, 3.35, 5.23, 6.97, 24.8, 48.5, 55.77, 87, 202];
number    = 1:1:length(names);

PdfFileName_new = sprintf('%s\\HeatingCycle_61', folder);

figure1 = figure('PaperOrientation', 'landscape', 'PaperType', 'A4');
    
k = 0;
ColorSet = jet(length(names));

subplot(1,4,1:3);
    for i=1:length(names)
        FS = importdata(sprintf('%s\\%s.txt', folder, names{i}));        
        h(i) = semilogy(FS.data(:,1), FS.data(:,2) + k*FS.data(:,2),...
            'Color', ColorSet(i,:), 'Linewidth', 2);
        hold on, grid on, box on;
        k = 10^i;
    end

    xlabel('{\it{2\theta}} (�)', 'FontSize', 18);
    ylabel('Intensity', 'FontSize', 18);
        set(gca, 'fontsize', 18);
    title(['SL - heating test'], 'FontSize', 18, 'HorizontalAlignment','center');

    c={sprintf('as\nprepared'), '145 �C', '215 �C', '290 �C', '360 �C', '430 �C',...
        '505 �C', '575 �C', '650 �C', '720 �C', '790 �C', '860 �C'}; % legend list
    for i = 1 : length(names)
        order(i) = length(names) - i + 1;
    end

    legend(h(order),c{order}, 'Location', 'North');

    set(gca, 'XTick', 24:2:66)
        xlim([24 66]);
        power = length(names) + 5;
        ylim([10 10^power]);
        breakxaxis([34 56], 0.05);
        


subplot(1,4,4);
    semilogx(roughness, number, '.', 'Markersize', 18);
    box on;
    xlabel('rms (nm)', 'FontSize', 18);
    title(['Roughness'], 'FontSize', 18, 'HorizontalAlignment','center');
        set(gca, 'fontsize', 18);
    xlim([1 500]);
    ylim([0.5 15.8]);

    grid on, box on;
    
    set(gca,'YTick',0:1:(length(names)+3))
    set(gca,'YTickLabel',{'', 'as prepared', '145 �C', '215 �C', '290 �C',...
        '360 �C', '430 �C', '505 �C', '575 �C', '650 �C', '720 �C', '790 �C', '860 �C', '', '', '', ''})

% annotations
y = 0.55;
annotation('line',  [0.8 0.82], [y y]);
annotation('arrow', [0.82 0.82], [y 0.85]);
text(3, 15, sprintf('annealing\npressure:\n10^{-4} mbar'), 'FontSize', 11, 'BackgroundColor', [1 1 1]);

annotation('line',  [0.8 0.82], [y-0.02 y-0.02]);
annotation('arrow', [0.82 0.82], [y-0.02 0.16]);
text(7, 1.5, sprintf('annealing\npressure:\n10^{-7} mbar'), 'FontSize', 11, 'BackgroundColor', [1 1 1]);

% save to the file
set(figure1, 'PaperPosition', [0 0 29.7 21]); 
    saveas(figure1, PdfFileName_new, 'pdf');
    