close all, clear all, clc

%% import files

figure1 = figure('PaperOrientation', 'portrait', 'PaperType', 'A4');
hold on;
box on;

sampleNumber = 124;
AFM = '\\fs01\holuj$\Dokumente\Results\AFM';
XRD = '\\fs01\holuj$\Dokumente\Results\XRD\SL-TH\SL-TH_124-';

for i=1:1

TwoTheta200 = importdata(sprintf('%s\\SL-TH_%0.f_200t2t.txt', XRD, i+sampleNumber-1));
RC200       = importdata(sprintf('%s\\SL-TH_%0.f_200rc.txt', XRD, i+sampleNumber-1));
TwoTheta400 = importdata(sprintf('%s\\SL-TH_%0.f_400T2T.txt', XRD, i+sampleNumber-1));
RC400       = importdata(sprintf('%s\\SL-TH_%0.f_400rc.txt', XRD, i+sampleNumber-1));

image20     = importdata(sprintf('%s\\sl_th_%0.f_20u.png', AFM, i+sampleNumber-1));
image1      = importdata(sprintf('%s\\sl_th_%0.f_1u.png', AFM, i+sampleNumber-1));

    subaxis(4,3,6*i-5, 'Spacing', 0.07, 'Padding', 0, 'Margin', 0.1)
        semilogy(TwoTheta200.data(:,1), TwoTheta200.data(:,2)./max(TwoTheta200.data(:,2)));
            xlabel('2\it{\theta} (�)');
            ylabel('Intensity');
            axis([25 33 0.8*min(TwoTheta200.data(:,2))./max(TwoTheta200.data(:,2)) 1.2]);
            grid on;
            title('\it{\theta} - 2\it{\theta} scan');
            legend(sprintf('%s', TwoTheta200.textdata{2}), 'Location', 'SouthEast');

    subaxis(4,3,6*i-4, 'Spacing', 0.07, 'Padding', 0, 'Margin', 0.1)
%         RC_fitAndPlot(RC200, 1);
        fit_PV(RC200.data(:,1),RC200.data(:,2));
        
    subaxis(4,3,6*i-3, 'Spacing', 0.01, 'Padding', 0, 'Margin', 0.05)
        image(image20);
        axis off tight square;
        
    subaxis(4,3,6*i-2, 'Spacing', 0.07, 'Padding', 0, 'Margin', 0.1)
        semilogy(TwoTheta400.data(:,1), TwoTheta400.data(:,2)./max(TwoTheta400.data(:,2)));
            xlabel('2\it{\theta} (�)');
            ylabel('Intensity');
            axis([56 66 0.8*min(TwoTheta400.data(:,2))./max(TwoTheta400.data(:,2)) 1.2]);
            grid on;
            title('\it{\theta} - 2\it{\theta} scan');
            legend(sprintf('%s', TwoTheta400.textdata{2}), 'Location', 'SouthEast');

    subaxis(4,3,6*i+-1, 'Spacing', 0.07, 'Padding', 0, 'Margin', 0.1)
%         RC_fitAndPlot(RC400, 1);
        fit_PV(RC400.data(:,1),RC400.data(:,2));
        
    subaxis(4,3,6*i, 'Spacing', 0.01, 'Padding', 0, 'Margin', 0.05)
        image(image1);
        axis off tight square;
        
end


    set(figure1, 'PaperPosition', [-0.5 -0.25 22 30]); %Position the plot further to the left and down. Extend the plot to fill entire paper.
    fileName = sprintf('%s\\merged_%0.f-%0.f', XRD, sampleNumber, sampleNumber+i);
    saveas(figure1, fileName, 'pdf');