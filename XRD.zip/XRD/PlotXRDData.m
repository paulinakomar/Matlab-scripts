close all, clear all, clc

%% names of the output files
name = '\\fs01\holuj$\Dokumente\Results\XRD\R_series\R68\R';
number = 68;
PdfFileName = sprintf('%s%0.f', name, number);
PngFileName = sprintf('%s%0.f', name, number);

%% import files
% FS = importdata(sprintf('%s%0.f_fs.txt', name, number));
% FS1 = importdata(sprintf('%s%0.f_200t2t.txt', name, number));  % import xrd full scan data
% FS2 = importdata(sprintf('%s%0.f_400t2t.txt', name, number));
% FS = [FS1.data; FS2.data];
RC200 = importdata(sprintf('%s%0.f_200rc.txt', name, number));              % import xrd rocking curve data
RC400 = importdata(sprintf('%s%0.f_400rc.txt', name, number));  
% RC_MgO = importdata(sprintf('%s%0.f_MgO_rc.txt', name, number));           % import xrd rocking curve of MgO substrate

% Phi = importdata('T1_phiScan.txt');             % import xrd phi scan of {111} peak

n=1;
%% Call functions to plot data
figure1 = figure('PaperOrientation', 'landscape', 'PaperType', 'A4');

subplot(2,2,1);
    RC_fitAndPlot(RC200)                        % plots of 200 rocking curves of the film
% subplot(2,2,2);
%      RC_MgO_plot(RC_MgO);                        % plots of rocking curves of MgO
subplot(2,2,2);
    RC_fitAndPlot(RC400)
% subplot(2,2,3:4);
%     FS_plot(FS, n);                             % plots of full scans
%     semilogy(FS(:,1), FS(:,2));
% subplot(2,2,2);
%     Phi_plot(Phi)                               % plots of phi scans of the {111} peak of the film
    
%% save to the file
set(figure1, 'PaperPosition', [-0.5 -0.25 30 20]); 
    saveas(figure1, PdfFileName, 'pdf');
%     print(figure1, '-dpng', PngFileName, '-r500');