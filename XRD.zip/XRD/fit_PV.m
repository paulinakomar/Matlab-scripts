function fit_PV(x,y)
% clear all, close all, clc
% 
% data = importdata('\\fs01\holuj$\Dokumente\Results\XRD\SL-TH\SL-TH_45-50\SL-TH_45_400rc.txt');
% x = data.data(:,1);
% y = data.data(:,2);

[fitresult, gof] = PseugoVoigt(x,y);
gauss_fit = fitresult.AG/(fitresult.wG*sqrt(2*pi))*exp(-((x-fitresult.xc)/(sqrt(2)*fitresult.wG)).^2);
lorentz_fit = (fitresult.AL/pi)*(fitresult.wL./((x-fitresult.xc).^2 + fitresult.wL^2));


fG = 2*fitresult.wG*sqrt(2*log(2));
fL = 2*fitresult.wL;
    FWHM = 0.5346*fL + sqrt(0.2166*fL^2 + fG^2);
    
% Plot fit with data.
figure();
hold on, grid on;
    plot(fitresult, x, y);
    plot(x, gauss_fit, 'g');
    plot(x, lorentz_fit, 'm');
        legend('Measured data', sprintf('Pseudo-Voigt fit\nFWHM = %0.4f�\nadjsquare = %0.4f',...
            FWHM, gof.adjrsquare), 'Gaussian component', 'Lorentzian component', 'Location', 'Best');
% Label axes
xlabel( '\it{\omega (�)}' );
ylabel( 'Intensity' );