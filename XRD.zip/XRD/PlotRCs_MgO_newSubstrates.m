clear all, close all, clc

%% names of the output files
folder = '\\fs01\holuj$\Dokumente\Results\XRD\MgO\2014-04-17';
name_new = {'SL-TH_73'; 'SL-TH_75'; 'SL-TH_77'; 'SL-TH_78'; 'SL-TH_79'; 'SL-TH_80'};
PdfFileName_new = sprintf('%s\\2014-04', folder);

figure1 = figure('PaperOrientation', 'landscape', 'PaperType', 'A4');
    annotation('textbox', [.38 .9 .6 .1], 'String', 'MgO substrates April 2014', 'LineStyle', 'none', 'FontSize', 18);
    
for i=1:length(name_new)
    RC_MgO = importdata(sprintf('%s\\%s_MgO_rc.txt', folder, name_new{i}));
    
    subplot(2,3,i);
        RC_MgO_plot(RC_MgO);
end

%% save to the file
set(figure1, 'PaperPosition', [-0.5 -0.25 30 20]); 
    saveas(figure1, PdfFileName_new, 'pdf');
%     print(figure2, '-dpng', PngFileName_new, '-r500');